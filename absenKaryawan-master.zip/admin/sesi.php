<?php 
	
	if (empty($_SESSION['idabsensiadmin']) AND empty($_SESSION['idabsensiadmin'])) {
		header("location: ../login.php");
	}
	


 ?>