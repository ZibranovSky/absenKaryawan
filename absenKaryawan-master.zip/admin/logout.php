<?php 
session_start();
unset($_SESSION['idabsensiadmin']);

header("location: ../");

 ?>