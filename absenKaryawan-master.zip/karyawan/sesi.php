<?php 
	
if (empty($_SESSION['idabsen2']) AND empty($_SESSION['idabsen2'])) {
		header("location: login.php");
	}	


 ?>