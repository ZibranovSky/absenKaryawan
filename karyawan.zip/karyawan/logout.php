<?php 
session_start();
unset($_SESSION['idabsensikaryawan']);
header("location: ../");
 ?>