<?php 
	
if (empty($_SESSION['idabsensikaryawan']) AND empty($_SESSION['idabsensikaryawan'])) {
		header("location: login.php");
	}	


 ?>